A Pen created at CodePen.io. You can find this one at http://codepen.io/chriscoyier/pen/eGcLw.

 Writeup on CSS-Tricks : http://css-tricks.com/dont-overthink-it-grids/